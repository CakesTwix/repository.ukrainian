From https://github.com/gade01/resource.images.moviegenreicons.xzener-flat/tree/master/resources
